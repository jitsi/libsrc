/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ymsg.network;

/**
 *
 * @author damencho
 */
public interface SessionPicture
{
    public byte[] getPicture();

    public String getPictureFileName();
}
