package ymsg.network;

public class NoSuchChatroomException extends java.lang.RuntimeException
{	NoSuchChatroomException(String m) { super(m); }
}
