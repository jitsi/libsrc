package ymsg.network;

public class FileTransferFailedException extends java.lang.RuntimeException
{	FileTransferFailedException(String m) { super(m); }
}
