package com.apple.eawt;

@Deprecated
public class ApplicationAdapter implements ApplicationListener {

    @Deprecated
    public ApplicationAdapter() {}

    @Deprecated
    public void handleAbout(ApplicationEvent event) {}

    @Deprecated
    public void handleOpenApplication(ApplicationEvent event) {}

    @Deprecated
    public void handleOpenFile(ApplicationEvent event) {}

    @Deprecated
    public void handlePreferences(ApplicationEvent event) {}

    @Deprecated
    public void handlePrintFile(ApplicationEvent event) {}

    @Deprecated
    public void handleQuit(ApplicationEvent event) {}

    @Deprecated
    public void handleReOpenApplication(ApplicationEvent event) {}
}
