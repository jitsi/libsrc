package com.apple.eawt;

/** @Since 10.6 Update 3 and 10.5 Update 8 */
public interface OpenURIHandler {
    public void openURI(AppEvent.OpenURIEvent e);
}
