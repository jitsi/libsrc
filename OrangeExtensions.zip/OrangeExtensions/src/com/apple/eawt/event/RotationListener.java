package com.apple.eawt.event;

/** 
 * @Since 10.5 Update 7 and 10.6 Update 2
 */
public interface RotationListener extends GestureListener {

    public void rotate(RotationEvent e);
}
