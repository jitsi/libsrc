package com.apple.eawt.event;

/** 
 * @Since 10.5 Update 7 and 10.6 Update 2
 */
public interface MagnificationListener extends GestureListener {

    public void magnify(MagnificationEvent e);
}
