package com.apple.eawt.event;

import javax.swing.JComponent;

/** 
 * @Since 10.5 Update 7 and 10.6 Update 2
 */
public final class GestureUtilities {
    
    public static void addGestureListenerTo(JComponent component, GestureListener listener) {}
    public static void removeGestureListenerFrom(JComponent component, GestureListener listener) {}
}
