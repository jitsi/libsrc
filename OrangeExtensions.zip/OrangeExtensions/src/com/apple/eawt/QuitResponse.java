package com.apple.eawt;

public class QuitResponse {

    public void cancelQuit() {}
    public void performQuit() {}
}
