package org.jivesoftware.whack;

import java.io.IOException;

/**
 *
 * @author Matt Tucker
 */
public class PacketReader {


}
