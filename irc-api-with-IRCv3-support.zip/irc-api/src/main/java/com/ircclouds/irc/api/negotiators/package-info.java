/**
 * Collection of CAP negotiators.
 *
 * @author Danny van Heumen
 */
package com.ircclouds.irc.api.negotiators;
