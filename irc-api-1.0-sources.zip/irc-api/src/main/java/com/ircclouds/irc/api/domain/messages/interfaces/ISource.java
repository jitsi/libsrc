package com.ircclouds.irc.api.domain.messages.interfaces;

public interface ISource
{
	ISource NULL_SOURCE = new ISource()
	{
	};
}
