package com.ircclouds.irc.api.ctcp;

import com.ircclouds.irc.api.*;

public interface DCCSendCallback extends ICallback<DCCSendResult, DCCSendException>
{

}