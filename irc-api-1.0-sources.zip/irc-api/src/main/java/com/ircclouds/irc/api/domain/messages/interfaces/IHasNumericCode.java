package com.ircclouds.irc.api.domain.messages.interfaces;

import java.io.*;

public interface IHasNumericCode extends Serializable
{
	Integer getNumericCode();
}
