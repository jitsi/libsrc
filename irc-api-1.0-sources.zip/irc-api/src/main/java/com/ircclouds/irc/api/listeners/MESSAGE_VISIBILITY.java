package com.ircclouds.irc.api.listeners;

public enum MESSAGE_VISIBILITY
{
	PRIVATE, PUBLIC
}
