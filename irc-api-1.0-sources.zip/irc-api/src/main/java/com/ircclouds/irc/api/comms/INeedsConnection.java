package com.ircclouds.irc.api.comms;

public interface INeedsConnection
{
	IConnection getConnection();
}
