package com.ircclouds.irc.api.filters;

public enum HowMany
{
	ALL, SOME
}
