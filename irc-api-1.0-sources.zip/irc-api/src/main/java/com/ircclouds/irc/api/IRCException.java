package com.ircclouds.irc.api;

public class IRCException extends Exception
{
	public IRCException(String aMsg)
	{
		super(aMsg);
	}
}
