package com.ircclouds.irc.api.commands;

public interface ICommand
{
	String asString();
}
