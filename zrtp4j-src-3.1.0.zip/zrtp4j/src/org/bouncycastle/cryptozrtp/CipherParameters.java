package org.bouncycastle.cryptozrtp;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
