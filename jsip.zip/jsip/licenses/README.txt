
NIST-CONDITIONS-OF-USE.txt
--------------------------

Applies to the classes under the hierarchy "gov.nist" and under the "tools"
and "test" hierarchy.


JSIP Spec License.pdf
---------------------

Applies to the classes under javax.sip hierarchy




