This directroy contains a viewer for viewing the signaling trace generated
from the NIST SIP stack.

Refer to ../../docs/tools/tracesviewer/README.html for more information on
how to use the traces viewer.

Author: Olivier Deruelle 
