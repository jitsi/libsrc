
These are NOT pure JAIN-SIP examples.

These are included for those building test frameworks who may find 
a pattern matching facility to be of use.

Ranga.

