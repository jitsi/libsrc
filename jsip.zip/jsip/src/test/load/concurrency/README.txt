
Test correct operation under load conditions. 
Runs 100 concurrent dialogs and make sure the dialogs are 
started and terminated properly.  

To run these tests:

make shootme
make shootist
