package test.unit.gov.nist.javax.sip.stack.dialog.b2bua.reinvite;

public enum Operation {
    FORWARD_INVITE,FORWARD_BYE,SEND_RE_INVITE;

}
