package net.sf.fmj.media.content.audio.basic;

import net.sf.fmj.media.handler.JavaSoundHandler;

/**
 * Experimental handler for AU files.
 * 
 * @author Ken Larson
 *
 */
public class Handler extends JavaSoundHandler
{

}
