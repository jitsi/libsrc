package net.sf.fmj.media.protocol;

public interface SourceStreamSlave
{
    public void connect();

    public void disconnect();
}
