package net.sf.fmj.media;

public interface Syncable
{
    /** Enable sync'ing of file descriptor */
    public void setSyncEnabled();
}
