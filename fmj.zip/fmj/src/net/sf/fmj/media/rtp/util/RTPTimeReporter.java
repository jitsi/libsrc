package net.sf.fmj.media.rtp.util;

public interface RTPTimeReporter
{
    public abstract long getRTPTime();
}
