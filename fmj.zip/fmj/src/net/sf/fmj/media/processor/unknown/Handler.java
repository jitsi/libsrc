package net.sf.fmj.media.processor.unknown;

import net.sf.fmj.media.*;

/**
 * The default processor to catch for all content types.
 */

public class Handler extends MediaProcessor
{
}
