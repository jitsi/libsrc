package net.sf.fmj.media.content.unknown;

import net.sf.fmj.media.*;

/**
 * The default player to catch for all content types.
 */

public class Handler extends MediaPlayer
{
}
