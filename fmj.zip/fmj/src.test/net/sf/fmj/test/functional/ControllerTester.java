package net.sf.fmj.test.functional;

import junit.framework.*;

/**
 * @author Warren Bloomer
 */
public class ControllerTester extends TestCase
{
    public void testAll()
    {
        // TODO write tests for controller.
    }
}
