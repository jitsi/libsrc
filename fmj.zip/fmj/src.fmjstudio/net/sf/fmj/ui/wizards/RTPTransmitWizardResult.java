package net.sf.fmj.ui.wizards;

/**
 * 
 * @author Ken Larson
 * 
 */
public class RTPTransmitWizardResult extends ProcessorWizardResult
{
}
