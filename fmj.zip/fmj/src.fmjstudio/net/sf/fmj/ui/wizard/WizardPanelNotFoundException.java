package net.sf.fmj.ui.wizard;

/**
 * Adapted Robert Eckstein's sample at
 * http://java.sun.com/developer/technicalArticles/GUI/swing/wizard/
 */
public class WizardPanelNotFoundException extends RuntimeException
{
    public WizardPanelNotFoundException()
    {
        super();
    }

}