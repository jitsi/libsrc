package com.sun.media.codec.audio;

public abstract class AudioCodec extends
        net.sf.fmj.media.codec.audio.AudioCodec
{
}
