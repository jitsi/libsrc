package com.sun.media;

public abstract class BasicCodec extends net.sf.fmj.media.BasicCodec
{
}
