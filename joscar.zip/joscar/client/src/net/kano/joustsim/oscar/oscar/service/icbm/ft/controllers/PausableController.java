package net.kano.joustsim.oscar.oscar.service.icbm.ft.controllers;

public interface PausableController {
  void pauseTransfer();

  void unpauseTransfer();
}
