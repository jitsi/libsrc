package net.kano.joustsim.oscar.oscar.service.icbm.dim;

import net.kano.joustsim.oscar.oscar.service.icbm.ft.state.SuccessfulStateInfo;

public class DirectimEndedInfo extends SuccessfulStateInfo { }
