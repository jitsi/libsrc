package net.kano.joustsim.oscar.oscar.service.icbm.ft.controllers;

public class TransferProblemException extends Exception {
}
