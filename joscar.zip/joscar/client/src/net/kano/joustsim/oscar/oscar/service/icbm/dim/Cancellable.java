package net.kano.joustsim.oscar.oscar.service.icbm.dim;

public interface Cancellable {
  boolean isCancelled();
}
