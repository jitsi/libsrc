package net.kano.joustsim.oscar.oscar.service.icbm;

public interface TypingNotificationConversation {
  void setTypingState(TypingState typingState);
}
