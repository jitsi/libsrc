package net.kano.joustsim.oscar.oscar.service.icbm.ft;

import net.kano.joustsim.oscar.oscar.service.icbm.ft.state.FailedStateInfo;

class DummyFailedStateInfo extends FailedStateInfo { }
