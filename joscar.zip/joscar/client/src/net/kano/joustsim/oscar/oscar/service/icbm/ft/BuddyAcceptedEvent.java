package net.kano.joustsim.oscar.oscar.service.icbm.ft;

import net.kano.joustsim.oscar.oscar.service.icbm.ft.events.RvConnectionEvent;

public class BuddyAcceptedEvent extends RvConnectionEvent { }
