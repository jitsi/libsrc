/*
 *  bspatch.h
 *  Sparkle
 *
 *  Created by Andy Matuschak on 1/11/10.
 *  Copyright 2010 Andy Matuschak. All rights reserved.
 *
 */

// So that we can use this method in SUBinaryDeltaApply.m.
// Silences the GCC warning that the prototype doesn't exist.
int bspatch(int argc, char * argv[]);
