//
//  SUBinaryDeltaUnarchiver.h
//  Sparkle
//
//  Created by Mark Rowe on 2009-06-03.
//  Copyright 2009 Mark Rowe. All rights reserved.
//

#ifndef SUBINARYDELTAUNARCHIVER_H
#define SUBINARYDELTAUNARCHIVER_H

#import <Cocoa/Cocoa.h>
#import "SUUnarchiver.h"

@interface SUBinaryDeltaUnarchiver : SUUnarchiver {
}

@end

#endif
