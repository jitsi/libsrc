package gov.nist.javax.sip.stack;

public interface QueuedMessageDispatchBase extends Runnable{
	long getReceptionTime();
}
