package com.explodingpixels.macwidgets;

public interface SourceListBadgeContentProvider {

    int getCounterValue();

}
