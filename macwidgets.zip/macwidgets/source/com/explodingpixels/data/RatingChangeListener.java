package com.explodingpixels.data;

public interface RatingChangeListener {

    void ratingChanged(Rating newRating);

}
